var reflection = function() {
	function functionName(func) {
		// Note that every function also has a 'name' property, making this exercise
		// a whole lot easier
		var regex = /function (.+)\(.*/;
		var matches = regex.exec(func.toString());
		if(matches === null) { // anonymous function
			return '(anonymous)';
		}
		return matches[1];
	}
	function hasProperty(object, propertyName) {
		return propertyName in object;
	}
	function hasProperties(object) {
		for(var i = 1; i < arguments.length; i++) {
			if(hasProperty(object, arguments[i]) === false) {
				return false;
			}
		}

		return true;
	}

	return {
		functionName: functionName,
		hasProperty: hasProperty,
		hasProperties: hasProperties
	};
}();

// Extend function prototype
Function.prototype.getName = function() {
	return reflection.functionName(this);
};

function test(param1, param2) {
	console.log('something');
}
console.log('Should return \'test\':', test.getName());