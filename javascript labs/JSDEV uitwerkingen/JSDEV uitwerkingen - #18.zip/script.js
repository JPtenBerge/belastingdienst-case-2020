function comNS(ns) {
	var split = ns.split('.');

	var parent = window;
	for(var i = 0; i < split.length; i++) {
		var piece = split[i];
		parent[piece] = parent[piece] || {};
		parent = parent[piece];
	}

	return parent;
}

!function(ns) {
	ns.getSize = function() {
		return 'It works!';
	};
}(comNS('com.infoSupport.someProject.v1.model'));

!function(ns) {
	ns.getHeight = function() {
		return 'It works too!';
	};
}(comNS('com.infoSupport.someProject.v1.model'));

console.log('The namespace:', com);
console.log('It should dynamically build a namespace:', com.infoSupport.someProject.v1.model.getSize());
console.log('It should dynamically build a namespace in a modular way, reusing if it already exists:', com.infoSupport.someProject.v1.model.getHeight());