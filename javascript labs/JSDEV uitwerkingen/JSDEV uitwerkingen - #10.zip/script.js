function sum() {
	var total = 0;
	for(var i = 0; i < arguments.length; i++) {
		total += arguments[i];
	}
	return total;
}
function sayHello(name) {
	var msg = 'Hello ' + (name || ''); // it does print out an extra space...
	console.log(msg);
}

// Test sum
console.log('Sum hoort 10 te leveren:', sum(1,2,3,4));

// Test sayHello
sayHello();
sayHello('JP');