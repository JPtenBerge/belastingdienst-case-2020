var me = { name: 'JP', city: 'Veenendaal' };
console.log('Me:', me);