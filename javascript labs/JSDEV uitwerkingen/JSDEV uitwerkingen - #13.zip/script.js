
// Function for creating overloads
function overload(funcA, funcB) {
	if(funcA.length === funcB.length) {
		throw new TypeError();
	}

	// Actual function that looks to the number of arguments supplied
	return function() {
		if(arguments.length === funcA.length) {
			return funcA.apply(this, arguments);
		}
		else if(arguments.length === funcB.length) {
			return funcB.apply(this, arguments);
		}
	};
}

var createVector = overload(
	function(a, b) {
		return { x: a, y: b };
	},
	function(length) {
		return { x: length / 1.414, y: length / 1.414 };
	}
);

console.log('Should return object { x: 3, y: 4 }:', createVector(3, 4));
console.log('Should return object { x: 5, y: 5 }:', createVector(7.07));