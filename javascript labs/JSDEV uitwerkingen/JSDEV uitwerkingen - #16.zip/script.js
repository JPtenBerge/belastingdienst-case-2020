!function(ns) {

	ns.Customer = function(id, name, city) {
		this.id = id;
		this.name = name;
		this.city = city;

		var nrOfUnpaidBills = 0;

		this.buyStuff = function() {
			nrOfUnpaidBills++;
		};
		this.payBill = function() {
			nrOfUnpaidBills--;
		};
		this.badPayer = function(n) {
			return nrOfUnpaidBills >= n;
		};

		this.toString = function() {
			return '(' + this.id + ') ' + this.name + ' - ' + this.city;
		};
	};
}(
	(
		window.com = window.com || {},
		com.yourCompany = com.yourCompany || {},
		com.yourCompany.CRM = com.yourCompany.CRM || {}
	)
);

console.log('Customer:', new com.yourCompany.CRM.Customer(3, 'Fred', 'Veenendaal'));
var cust = new com.yourCompany.CRM.Customer(4, 'Fred', 'Veenendaal');
console.log('nrOfUnpaidBills should not be accessible (undefined):', cust.nrOfUnpaidBills);
cust.buyStuff();
cust.buyStuff();
cust.buyStuff();
console.log('badPayer() should return true with n=2 and 3 unpaid bills:', cust.badPayer(2));
console.log('badPayer() should return false with n=5 and 3 unpaid bills:', cust.badPayer(5));
console.log('Should overwrite the toString() function:', cust.toString());