function Customer(id, name, city) {
	this.id = id;
	this.name = name;
	this.city = city;

	var nrOfUnpaidBills = 0;

	this.unpaidBillsChanged = new EventHandler();

	this.buyStuff = function() {
		nrOfUnpaidBills++;
		this.unpaidBillsChanged.invoke(this, { bills: nrOfUnpaidBills });
	};
	this.payBill = function() {
		nrOfUnpaidBills--;
		this.unpaidBillsChanged.invoke(this, { bills: nrOfUnpaidBills });
	};
	this.badPayer = function(n) {
		return nrOfUnpaidBills >= n;
	};

	this.toString = function() {
		return '(' + this.id + ') ' + this.name + ' - ' + this.city;
	};
}
function EventHandler() {
	var listeners = [];

	this.addListener = function(listener) {
		if(typeof listener === 'function') {
			listeners.push(listener);
		}
	};
	this.removeListener = function(listener) {
		var index = listeners.indexOf(listener);
		if(index !== -1) {
			listeners.splice(index, 1);
		}
	};
	this.invoke = function(sender, args) {
		for(var i = 0; i < listeners.length; i++) {
			listeners[i](sender, args);
		}
	};
}

function accountant(sender, args) {
	console.log('Sender:', sender.toString());
	console.log('Bills:', args.bills);
}
var bob = new Customer(102, 'Bob', 'Utrecht');
bob.unpaidBillsChanged.addListener(accountant);
bob.buyStuff();
bob.payBill();