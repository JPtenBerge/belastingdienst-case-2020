function contains(array, item) {
	return array.indexOf(item) !== -1;
}
function add(array, item) {
	array.push(item);
}
function remove(array, item) {
	var index = array.indexOf(item);
	array.splice(index, 1);
}
function sum(array) {
	var total = 0;
	for(var i = 0; i < array.length; i++) {
		total += array[i];
	}
	return total;
}

// Test contains
var containsTestArray = [1,2,3];
console.log('Array zou een 3 moeten bevatten:', contains(containsTestArray, 3));

// Test add
var addTestArray = [1,2,3];
add(addTestArray, 4);
console.log('Array hoort een 4 als item te bevatten:', addTestArray);

// Test remove
var removeTestArray = [1,2,3];
remove(removeTestArray, 2);
console.log('Array hoort geen 2 meer te bevatten:', removeTestArray);

// Test sum
console.log('Sum hoort 10 te leveren:', sum([1,2,3,4]));