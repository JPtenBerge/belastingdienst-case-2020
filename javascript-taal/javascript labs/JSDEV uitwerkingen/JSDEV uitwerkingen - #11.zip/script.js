var reflection = function() {
	function functionName(func) {
		// Note that every function also has a 'name' property, making this exercise
		// a whole lot easier
		var regex = /function (.+)\(.*/;
		var matches = regex.exec(func.toString());
		if(matches === null) { // anonymous function
			return '(anonymous)';
		}
		return matches[1];
	}
	function hasProperty(object, propertyName) {
		return propertyName in object;
	}
	function hasProperties(object) {
		for(var i = 1; i < arguments.length; i++) {
			if(hasProperty(object, arguments[i]) === false) {
				return false;
			}
		}

		return true;
	}

	return {
		functionName: functionName,
		hasProperty: hasProperty,
		hasProperties: hasProperties
	};
}();

// Test reflection functionName
function test(param1, param2) {
	console.log('something');
}
console.log('functionName should find \'test\':', reflection.functionName(test));
console.log('functionName should detect anonymous:', reflection.functionName(function() { }));

// Test reflection hasProperty
var obj = { x: 42 };
console.log('hasProperty should give true:', reflection.hasProperty(obj, 'x'));
console.log('hasProperty should give false:', reflection.hasProperty(obj, 'y'));

// Test reflection hasProperty
var obj2 = { x: 42, y: 108 };
console.log('hasProperties should give true:', reflection.hasProperties(obj2, 'x', 'y'));
console.log('hasProperties should give false:', reflection.hasProperties(obj2, 'y', 'z'));