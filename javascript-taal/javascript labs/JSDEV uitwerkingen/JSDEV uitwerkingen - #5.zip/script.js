var values = [false, null, undefined, 0, -0, '', NaN];
for(var i = 0; i < values.length; i++) {
	console.log('Waarde', values[i], 'levert', +!values[i] === 1);
}